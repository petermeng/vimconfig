return {
  component = require "astronvim.utils.status.component",
  condition = require "astronvim.utils.status.condition",
  env = require "astronvim.utils.status.env",
  heirline = require "astronvim.utils.status.heirline",
  hl = require "astronvim.utils.status.hl",
  init = require "astronvim.utils.status.init",
  provider = require "astronvim.utils.status.provider",
  utils = require "astronvim.utils.status.utils",
}
